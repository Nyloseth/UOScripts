using System;
using Server.Mobiles;

namespace Server.Items
{
    public class TheVoidCoin : Item
    {
        [Constructable]
        public TheVoidCoin()
            : this(1)
        {
        }

        [Constructable]
        public TheVoidCoin(int amountFrom, int amountTo)
            : this(Utility.RandomMinMax(amountFrom, amountTo))
        {
        }

        [Constructable]
        public TheVoidCoin(int amount)
            : base(0xEED)
        {
            Name = "Void Coin";
            Hue = 2728;
            this.Stackable = true;
            this.Amount = amount;
        }

        public TheVoidCoin(Serial serial)
            : base(serial)
        {
        }

        public override double DefaultWeight
        {
            get
            {
                return 0.00;
            }
        }
        public override int GetDropSound()
        {
            if (this.Amount <= 1)
                return 0x2E4;
            else if (this.Amount <= 5)
                return 0x2E5;
            else
                return 0x2E6;
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}