//===============================================================================
//                      This script was created by Gizmo's UoDevPro
//                      This script was created on 11/29/2018 03:05:59
//===============================================================================


using System;
using Server;
using Server.Items;
using Server.Mobiles;

namespace Server.Engines.Quests
{
	public class WhyanEvilUnicorn : BaseQuest
	{
		public WhyanEvilUnicorn() : base()
		{
			//The player must slay 1 Evil Unicorn
			this.AddObjective(new SlayObjective(typeof(EvilUnicorn), "Evil Unicorn", 1));
			//Reward the Player Gold
			this.AddReward(new BaseReward("3000-9000 Gold"));
			//Reward the Player Magic Item(s)
			this.AddReward(new BaseReward("5 Magic Item(s)"));
			this.AddReward(new BaseReward(typeof(TheVoidCoin), 500, "500 Void Coins"));
		}

		//The player will have a delay before they can redo quest again
		public override TimeSpan RestartDelay { get { return TimeSpan.FromMinutes(60); } }

		//Quest Title
		public override object Title { get { return "Why an Evil Unicorn"; } }
		//Quest Description
		public override object Description { get { return "Hi, I seem to have an issure here...  I've seen a nightmarish sight, unicorns killing things, though I have found something out about these things... They were corrupted by something. Unicorns are not supposed to be evil, they aren't supposed to kill things unless told to do so.  So what I'm looking for is for someone to put at least one of them out of their misery.  They are obviously suffering!"; } }
		//Quest Refuse Message
		public override object Refuse { get { return "I guess the greater good won't prevail here."; } }
		//Quest Uncompleted Message
		public override object Uncomplete { get { return "You haven't killed one yet? This is important, please please kill one, they are all suffering."; } }
		//Quest Completed Message
		public override object Complete { get { return "Thank you so much, here's a reward for your hard work!"; } }

		public override void GiveRewards()
		{
			//Give Gold to player in form of a bank check
			BankCheck gold = new BankCheck(Utility.RandomMinMax(3000, 9000));
			if(!Owner.AddToBackpack( gold ))
				gold.MoveToWorld(Owner.Location,Owner.Map);

			Item item;

			//Random Magic Item #1
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 10, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 10, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 10, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 10, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #2
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 10, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 10, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 10, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 10, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #3
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 10, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 10, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 10, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 10, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #4
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 10, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 10, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 10, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 10, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #5
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 10, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 10, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 10, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 10, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			base.GiveRewards();
		}

		public override void Serialize(GenericWriter writer)
		{
			base.Serialize(writer);
			writer.Write((int)0); // version
		}
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize(reader);
			int version = reader.ReadInt();
		}
	}
}
