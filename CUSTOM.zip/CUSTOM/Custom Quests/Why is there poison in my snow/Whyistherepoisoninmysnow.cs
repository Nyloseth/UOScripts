//===============================================================================
//                      This script was created by Gizmo's UoDevPro
//                      This script was created on 11/30/2018 03:26:28
//===============================================================================


using System;
using Server;
using Server.Items;
using Server.Mobiles;

namespace Server.Engines.Quests
{
	public class Whyistherepoisoninmysnow : BaseQuest
	{
		public Whyistherepoisoninmysnow() : base()
		{
			//The player must slay 20 Frost Scorpions
			this.AddObjective(new SlayObjective(typeof(FrostScorpion), "Frost Scorpions", 20));
			//Reward the Player Gold
			this.AddReward(new BaseReward("2000-7000 Gold"));
			//Reward the Player Magic Item(s)
			this.AddReward(new BaseReward("3 Magic Item(s)"));
			this.AddReward(new BaseReward(typeof(TheVoidCoin), 400, "400 Void Coins"));
		}

		//The player will have a delay before they can redo quest again
		public override TimeSpan RestartDelay { get { return TimeSpan.FromMinutes(60); } }

		//Quest Title
		public override object Title { get { return "Why is there poison in my snow"; } }
		//Quest Description
		public override object Description { get { return "By golly I'm having a huge issue.  It seems like we have scorpions not only in the forests now, but in the tundra too! This will do no good, no good at all!  I need those pests gone, and the sooner they are gone, the better! Could you help me and get rid of a few of those dastardly things?"; } }
		//Quest Refuse Message
		public override object Refuse { get { return "Ugh, I'm going to need to find a different person to be the pest killer than."; } }
		//Quest Uncompleted Message
		public override object Uncomplete { get { return "You haven't killed them yet? Please get rid of those darned things! I don't like them one bit!"; } }
		//Quest Completed Message
		public override object Complete { get { return "Here you go! Thank you for getting rid of those things!"; } }

		public override void GiveRewards()
		{
			//Give Gold to player in form of a bank check
			BankCheck gold = new BankCheck(Utility.RandomMinMax(2000, 7000));
			if(!Owner.AddToBackpack( gold ))
				gold.MoveToWorld(Owner.Location,Owner.Map);

			Item item;

			//Random Magic Item #1
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 8, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 8, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 8, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 8, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #2
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 8, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 8, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 8, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 8, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #3
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 8, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 8, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 8, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 8, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			base.GiveRewards();
		}

		public override void Serialize(GenericWriter writer)
		{
			base.Serialize(writer);
			writer.Write((int)0); // version
		}
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize(reader);
			int version = reader.ReadInt();
		}
	}
}
