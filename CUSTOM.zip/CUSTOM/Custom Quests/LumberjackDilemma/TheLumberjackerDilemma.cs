//===============================================================================
//                      This script was created by Gizmo's UoDevPro
//                      This script was created on 10/28/2018 6:50:15 PM
//===============================================================================


using System;
using Server;
using Server.Items;
using Server.Mobiles;

namespace Server.Engines.Quests
{
	public class TheLumberjackDilemma : BaseQuest
	{
		public TheLumberjackDilemma() : base()
		{
			//The player must slay 20 Mongbat
			this.AddObjective(new SlayObjective(typeof(Mongbat), "Mongbat", 10));
			//Reward the Player Gold
			this.AddReward(new BaseReward(typeof(Gold), 1000, 1062577));
			//Quest Has Chance at Special Item
			this.AddReward(new BaseReward(typeof(TheVoidCoin), 10, "10 Void Coins"));
		}

		//The player will have a delay before they can redo quest again
		public override TimeSpan RestartDelay { get { return TimeSpan.FromMinutes(60); } }

		//Quest Title
		public override object Title { get { return "The Lumberjacker Dilemma"; } }
		//Quest Description
		public override object Description { get { return "Hello good citizen, I seem to be having a problem recently.  Anytime I go out to help collect wood fro the town, I have an issue with mongbats attacking me.  We've been able to stop them so far, but we're going to need a little help.  Could you help cut down the mongbat population for us?"; } }
		//Quest Refuse Message
		public override object Refuse { get { return "Well, killing mongbats isn't for everyone.  If you ever change your mind I'll give you something special for it."; } }
		//Quest Uncompleted Message
		public override object Uncomplete { get { return "You still have some mongbats to kill for us.  If you could take care of that, I'll be be able to help you."; } }
		//Quest Completed Message
		public override object Complete { get { return "Thank you so much citizen  for helping us kill those darned mongbats.  Here's something for your troubles."; } }

		public override void Serialize(GenericWriter writer)
		{
			base.Serialize(writer);
			writer.Write((int)0); // version
		}
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize(reader);
			int version = reader.ReadInt();
		}
	}
}
