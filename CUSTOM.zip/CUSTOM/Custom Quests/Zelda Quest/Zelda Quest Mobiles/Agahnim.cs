using System;
using Server;
using Server.Items;

namespace Server.Mobiles
{
	[CorpseName( "a Agahnim's corpse" )]
	public class Agahnim : BaseCreature
	{
		[Constructable]
		public Agahnim () : base( AIType.AI_Mage, FightMode.Closest, 10, 1, 0.2, 0.4 )
		{
			Name = "Agahnim";
			Body = 0x92;
			BaseSoundID = 362;

			SetStr( 796, 1555 );
			SetDex( 5586, 5615 );
			SetInt( 5436, 5475 );

			SetHits( 15078, 21095 );

			SetDamage( 30, 45 );

			SetDamageType( ResistanceType.Physical, 100 );

			SetResistance( ResistanceType.Physical, 55, 85 );
			SetResistance( ResistanceType.Fire, 60, 70 );
			SetResistance( ResistanceType.Cold, 30, 40 );
			SetResistance( ResistanceType.Poison, 55, 75 );
			SetResistance( ResistanceType.Energy, 65, 85 );

			SetSkill( SkillName.EvalInt, 130.1, 40.0 );
			SetSkill( SkillName.Magery, 130.1, 40.0 );
			SetSkill( SkillName.MagicResist, 199.1, 200.0 );
			SetSkill( SkillName.Tactics, 197.6, 200.0 );
			SetSkill( SkillName.Wrestling, 120.1, 162.5 );

			Fame = 15000;
			Karma = -15000;

			VirtualArmor = 60;

									
			PackItem( new Mirror() );
		}

		public override void GenerateLoot()
		{
			AddLoot( LootPack.FilthyRich, 2 );
			AddLoot( LootPack.Gems, 8 );
		}

		public override bool AutoDispel{ get{ return true; } }
		public override int TreasureMapLevel{ get{ return 4; } }
		
		
		
		

		public Agahnim( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}