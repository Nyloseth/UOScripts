// Created by Script Creator
using System;
using Server.Items;

namespace Server.Mobiles
{
     [CorpseName( "Ganon's corpse" )]
     public class Ganon: BaseCreature
     {
         [Constructable]
		public Ganon () : base( AIType.AI_Melee, FightMode.Closest, 10, 1, 0.5, 0.7 ) 
         {
             Name = "Ganon";
             Body = 796;
             BaseSoundID = 609;
             SetStr( 1050 );
             SetDex( 1300 );
             SetInt( 1300 );
             SetHits( 30000 );
             SetDamage( 40 );
             SetDamageType( ResistanceType.Physical, 20 );
             SetDamageType( ResistanceType.Fire, 25 );
             SetDamageType( ResistanceType.Cold, 25 );
             SetDamageType( ResistanceType.Energy, 25 );
             SetDamageType( ResistanceType.Poison, 25 );

             SetResistance( ResistanceType.Physical, 80 );
             SetResistance( ResistanceType.Fire, 80 );
             SetResistance( ResistanceType.Cold, 50 );
             SetResistance( ResistanceType.Energy, 80 );
             SetResistance( ResistanceType.Poison, 50 );
	SetSkill( SkillName.MagicResist, 140.1, 140.0 );
	SetSkill( SkillName.Tactics, 125.1, 135.0 );
	SetSkill( SkillName.Wrestling, 140.1, 185.0 );



             Fame = 10000;
             Karma = -5000;
             VirtualArmor = 10;
		
		PackItem( new GanonHead() );
		}

		public override void GenerateLoot()
		{
			AddLoot( LootPack.FilthyRich, 2 );
			AddLoot( LootPack.Gems, 8 );
		}

		public override bool AutoDispel{ get{ return true; } }
        

		 public Ganon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
    		 {
        			 base.Serialize( writer );
        			 writer.Write( (int) 0 );
     		}

		public override void Deserialize( GenericReader reader )
     		{
        			 base.Deserialize( reader );
         			int version = reader.ReadInt();
     		}
  	 }
}
