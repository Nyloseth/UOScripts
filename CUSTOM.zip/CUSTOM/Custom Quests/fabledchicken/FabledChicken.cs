//===============================================================================
//                      This script was created by Gizmo's UoDevPro
//                      This script was created on 11/29/2018 00:13:02
//===============================================================================


using System;
using Server;
using Server.Items;
using Server.Mobiles;

namespace Server.Engines.Quests
{
	public class FabledChicken : BaseQuest
	{
		public FabledChicken() : base()
		{
			//The player must slay 1 PurpleChicken
			this.AddObjective(new SlayObjective(typeof(PurpleChicken), "Purple Chicken", 1));
			//Reward the Player Gold
			this.AddReward(new BaseReward("6000-12000 Gold"));
			//Reward the Player Magic Item(s)
			this.AddReward(new BaseReward("5 Magic Item(s)"));
			this.AddReward(new BaseReward(typeof(TheVoidCoin), 1000, "1000 Void Coins"));
		}

		//The player will have a delay before they can redo quest again
		public override TimeSpan RestartDelay { get { return TimeSpan.FromMinutes(60); } }

		//Quest Title
		public override object Title { get { return "Fabled Chicken"; } }
		//Quest Description
		public override object Description { get { return "Hi, I have a request for you... Could you go and kill this weird looking chicken for me?  It's purple...  And it's a mean little thing.  You might want to take some friends with you to make sure you don't get killed by this thing.  Legend has it, the purple chicken is the spawn of a demon...  Some say it's the offspring of a dragon.  Frankly, I just want to see if it can be killed!"; } }
		//Quest Refuse Message
		public override object Refuse { get { return "I guess you aren't a legend.  Hope you have a good day sir."; } }
		//Quest Uncompleted Message
		public override object Uncomplete { get { return "Have you killed the purple chicken yet?"; } }
		//Quest Completed Message
		public override object Complete { get { return "Oh wow, you killed a purple chicken?  I am quite thoroughly impressed good sir!"; } }

		public override void GiveRewards()
		{
			//Give Gold to player in form of a bank check
			BankCheck gold = new BankCheck(Utility.RandomMinMax(6000, 12000));
			if(!Owner.AddToBackpack( gold ))
				gold.MoveToWorld(Owner.Location,Owner.Map);

			Item item;

			//Random Magic Item #1
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 10, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 10, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 10, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 10, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #2
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 10, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 10, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 10, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 10, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #3
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 10, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 10, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 10, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 10, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #4
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 10, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 10, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 10, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 10, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #5
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 10, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 10, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 10, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 10, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			base.GiveRewards();
		}

		public override void Serialize(GenericWriter writer)
		{
			base.Serialize(writer);
			writer.Write((int)0); // version
		}
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize(reader);
			int version = reader.ReadInt();
		}
	}
}
