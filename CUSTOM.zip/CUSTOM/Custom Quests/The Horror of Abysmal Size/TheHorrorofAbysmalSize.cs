//===============================================================================
//                      This script was created by Gizmo's UoDevPro
//                      This script was created on 12/2/2018 01:45:10
//===============================================================================


using System;
using Server;
using Server.Items;
using Server.Mobiles;

namespace Server.Engines.Quests
{
	public class TheHorrorofAbysmalSize : BaseQuest
	{
		public TheHorrorofAbysmalSize() : base()
		{
			//The player must slay 10 Abysmal Horror
			this.AddObjective(new SlayObjective(typeof(AbysmalHorror), "Abysmal Horror", 10));
			//Reward the Player Gold
			this.AddReward(new BaseReward("500-10000 Gold"));
			//Reward the Player Magic Item(s)
			this.AddReward(new BaseReward("3 Magic Item(s)"));
			this.AddReward(new BaseReward(typeof(TheVoidCoin), 500, "500 Void Coins"));
		}

		//The player will have a delay before they can redo quest again
		public override TimeSpan RestartDelay { get { return TimeSpan.FromMinutes(120); } }

		//Quest Title
		public override object Title { get { return "The Horror of Abysmal Size"; } }
		//Quest Description
		public override object Description { get { return "Those things... Those things I have nightmares about.  They killed my daughter... and now they have killed my wife.  I want revenge but I am such a weak man...  Please, if you could kill those THINGs for me...  I think they are called Abysmal Horrors.  Please, destroy them for me!"; } }
		//Quest Refuse Message
		public override object Refuse { get { return "I... I guess I will need to become stronger to kill them myself."; } }
		//Quest Uncompleted Message
		public override object Uncomplete { get { return "I see you haven't killed enough.  Please, get rid of those things for me."; } }
		//Quest Completed Message
		public override object Complete { get { return "Thank you, I can now finally rest in peace."; } }

		public override void GiveRewards()
		{
			//Give Gold to player in form of a bank check
			BankCheck gold = new BankCheck(Utility.RandomMinMax(500, 10000));
			if(!Owner.AddToBackpack( gold ))
				gold.MoveToWorld(Owner.Location,Owner.Map);

			Item item;

			//Random Magic Item #1
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 6, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 6, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 6, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 6, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #2
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 6, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 6, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 6, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 6, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			//Random Magic Item #3
			item = Loot.RandomArmorOrShieldOrWeaponOrJewelry();
			if( item is BaseWeapon )
				BaseRunicTool.ApplyAttributesTo((BaseWeapon)item, 6, 20, 70 );
			if( item is BaseArmor )
				BaseRunicTool.ApplyAttributesTo((BaseArmor)item, 6, 20, 70 );
			if( item is BaseJewel )
				BaseRunicTool.ApplyAttributesTo((BaseJewel)item, 6, 20, 70 );
			if( item is BaseHat )
				BaseRunicTool.ApplyAttributesTo((BaseHat)item, 6, 20, 70 );
			if(!Owner.AddToBackpack( item ) )
			{
				item.MoveToWorld(Owner.Location,Owner.Map);
			}

			base.GiveRewards();
		}

		public override void Serialize(GenericWriter writer)
		{
			base.Serialize(writer);
			writer.Write((int)0); // version
		}
		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize(reader);
			int version = reader.ReadInt();
		}
	}
}
