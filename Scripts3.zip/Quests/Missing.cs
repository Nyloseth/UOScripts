using System;
using Server.Items;

namespace Server.Engines.Quests
{
    public class Missing : BaseQuest
    {
        public Missing()
            : base()
        {
            this.AddObjective(new ObtainObjective(typeof(ArielHavenWritofMembership), "Ariel Haven Writ of Membership", 4, 0x2831));

            this.AddReward(new BaseReward(typeof(CandlewoodTorch), "Candlewood Torch"));
            this.AddReward(new BaseReward(typeof(TheVoidCoin), 10, "10 Void Coins"));
        }

        public override Type NextQuest
        {
            get
            {
                return typeof(EndingtheThreat);
            }
        }
        public override object Title
        {
            get
            {
                return 1094949;
            }
        }//Missing
        public override object Description
        {
            get
            {
                return 1094951;
            }
        }
        /*Very well, fare thee well traveler.  I would not press our problems upon you if you are not willing.  
        I pray that my people are simply trying to secure some treasure they found.*/
        public override object Refuse
        {
            get
            {
                return 1094952;
            }
        }
        /*Greetings, have you any news of my people?  I am encouraged to see you well!*/
        public override object Uncomplete
        {
            get
            {
                return 1094953;
            }
        }
        /*Oh, this is indeed sad news.  It seems my worst fears have been realized! 
        These writs were given to Evan and Kevin Brightwhistle, Sergio Taylor, and Sarah Bootwell.
        Based on your description of the ghastly scene, they have met a most untimely end!
        This is a great setback to our society as they were each great friends to me and an asset to the society.
        'Tis strange that there were only four bodies.... 
        There was a fifth member of the party, Neville Brightwhistle, but he was the youngest and least experienced of the party so if his elder brothers are lost, 
        surely young Neville met a similar fate. �Tis a tragedy, surely.
        Please take this torch with my thanks.  It may not seem like much, but it is magic and will never burn out.  
        You will find that rotworms fear fire so it will protect you from them as you venture further into these cursed halls.
        Tread carefully traveller, each member of the party had one of these so I suspect that the rotworms are not what ended their lives.*/
        public override object Complete
        {
            get
            {
                return 1094956;
            }
        }
        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}