using System;

namespace Server.Engines.CannedEvil
{
    public enum ChampionSkullType
    {
        None = -1,
        Power,
        Enlightenment,
        Venom,
        Pain,
        Greed,
        Death,
        Terror,
        Infuse
    }
}